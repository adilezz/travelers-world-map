import json
places = json.load(open("places.json"))
focus  = json.load(open("focus.json"))
world  = json.load(open("world.json"))
DATA = json.dumps(dict(P=places["places"], M=places["meta"], A=places["archLabels"],
                       F=focus, W=world), separators=(",",":"))
html = open("template.html", encoding="utf-8").read().replace("/*__DATA__*/", DATA)
open("index.html","w",encoding="utf-8").write(html)
import os; print("index.html", os.path.getsize("index.html")//1024, "KB")
